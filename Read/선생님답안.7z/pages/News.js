import React, { memo } from 'react';
import styled from 'styled-components';

// 상태값을 로드하기 위한 hook과 action함수를 dispatch할 hook 참조
import { useSelector, useDispatch } from 'react-redux'
// Slice에 정의된 액션함수들 참조
import { getNewsList } from '../slices/NewsSlice';

import NewsItem from '../components/NewsItem';
import Spinner from '../components/Spinner';
import ErrorView from '../components/ErrorView';

const ListContainer = styled.ul`
    list-style: none;
    padding: 0;
    margin: 0;
    width: 100%;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    margin-bottom: 30px;
`;

const News = memo(() => {
    const dispatch = useDispatch();
    const { data, loading, error } = useSelector((state) => state.news);

    React.useEffect(() => {
        dispatch(getNewsList());
    }, [dispatch]);

    return (
        <div>
            <Spinner visible={loading} />
            {error ? <ErrorView error={error} /> : (
                <ListContainer>
                    {data && data.map((v, i) => <NewsItem key={i} item={v}/>)}
                </ListContainer>
            )}
        </div>
    );
});

export default News;
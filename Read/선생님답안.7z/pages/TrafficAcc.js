import React, { memo } from 'react';
import styled from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import { getTrafficAccident } from '../slices/TrafficAccidentSlice';

import Spinner from '../components/Spinner';
import ErrorView from '../components/ErrorView';
import Table from '../components/Table';

const SelectContainer = styled.div`
    position: sticky;
    top: 0;
    background-color: #fff;
    border-top: 1px solid #eee;
    border-bottom: 1px solid #eee;
    padding: 10px 0;
    margin: 0;
 
    select {
        margin-right: 15px;
        font-size: 16px;
        padding: 5px 10px;
    }
`;

const TrafficAcc = memo(() => {
    const dispatch = useDispatch();
    const { data, loading, error } = useSelector((state) => state.trafficAccident);
    const [year, setYear] = React.useState('');

    const onSelectChange = React.useCallback(e => {
        e.preventDefault();
        const current = e.target;
        const value = current[current.selectedIndex].value;
        setYear(value);
    }, []);

    React.useEffect(() => {
        dispatch(getTrafficAccident({ year: year }));
    }, [dispatch, year]);

    return (
        <div>
            {/* 로딩바 */}
            <Spinner visible={loading} />

            {/* 검색 조건 드롭다운 박스 */}
            <SelectContainer>
                <select name='year' onChange={onSelectChange} value={year} >
                    <option value="">-- 년도 선택 --</option>
                    {[...new Array(2018 - 2005 + 1)].map((v, i) => {
                        return (<option key={i} value={2005 + i}>{2005 + i}년도</option>)
                    })}
                </select>
            </SelectContainer>

            {error ? <ErrorView error={error} /> : (
                <Table>
                    <thead>
                        <tr>
                            <th>번호</th>
                            <th>년도</th>
                            <th>월</th>
                            <th>교통사고 건수</th>
                            <th>사망자 수</th>
                            <th>부상자 수</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map(({ id, year, month, accident, death, injury }, i) => {
                            return (
                                <tr key={i}>
                                    <td>{id}</td>
                                    <td>{year}년</td>
                                    <td>{month}월</td>
                                    <td>{accident.toLocaleString()}건</td>
                                    <td>{death.toLocaleString()}명</td>
                                    <td>{injury.toLocaleString()}명</td>
                                </tr>
                            );
                        })}
                    </tbody>

                    <tfoot>
                        <tr>
                            <th colSpan="3">합계</th>
                            <th>{data.map((v, i) => v.accident).reduce((p, c) => p + c, 0).toLocaleString()}건</th>
                            <th>{data.map((v, i) => v.death).reduce((p, c) => p + c, 0).toLocaleString()}명</th>
                            <th>{data.map((v, i) => v.injury).reduce((p, c) => p + c, 0).toLocaleString()}명</th>
                        </tr>
                    </tfoot>
                </Table>
            )}
        </div>
    );
});

export default TrafficAcc;
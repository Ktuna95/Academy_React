import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios';

// http://localhost:3001/traffic_acc?year=2007
const API_URL = 'http://localhost:3001/traffic_acc';

export const getTrafficAccident = createAsyncThunk("TrafficAccidentSlice/getTrafficAccident", async (payload, { rejectWithValue }) => {
    let result = null;

    try {
        const data = {};

        if (payload.year) {
            data.year = payload.year;
        }

        result = await axios.get(API_URL, {
            params: data
        });
    } catch (err) {
        result = rejectWithValue(err.response);
    }

    return result;
});

const TrafficAccidentSlice = createSlice({
    name: "trafficAccident",
    initialState: {
        data: null,
        loading: false,
        error: null
    },
    reducers: {},
    extraReducers: {
        [getTrafficAccident.pending]: (state, { payload }) => {
            return { ...state, loading: true }
        },
        [getTrafficAccident.fulfilled]: (state, { payload }) => {
            return {
                data: payload?.data, 
                loading: false,
                error: null
            }
        },
        [getTrafficAccident.rejected]: (state, { payload }) => {
            return {
                data: payload?.data, 
                loading: false,
                error: {
                    code: payload?.status ? payload.status : 500,
                    message: payload?.statusText ? payload.statusText : 'Server Error'
                }
            }
        }
    },
});

export default TrafficAccidentSlice.reducer;
import { configureStore } from '@reduxjs/toolkit';
import NewsSlice from './slices/NewsSlice';
import TrafficAccidentSlice from './slices/TrafficAccidentSlice';

const store = configureStore({
    reducer: {
        news: NewsSlice,
        trafficAccident: TrafficAccidentSlice
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware({serializableCheck: false}),
    devTools: true
});

export default store;